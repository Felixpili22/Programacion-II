document.addEventListener('DOMContentLoaded', function() {
  // Menú Hamburguesa 
  const hamburger = document.querySelector('.hamburger');
  const menu = document.querySelector('.menu');
  
  if (hamburger && menu) {
    hamburger.addEventListener('click', function() {
      this.classList.toggle('active');
      menu.classList.toggle('active');
    });
  }

  // Formulario de Contacto
  const formulario = document.getElementById('formContacto');
  const mensajeExito = document.getElementById('mensajeExito');

  if (formulario && mensajeExito) {
    formulario.addEventListener('submit', function(e) {
      e.preventDefault();
      
      let isValid = true;
      const requiredFields = this.querySelectorAll('[required]');
      
      requiredFields.forEach(field => {
        field.style.borderColor = '#ddd';
        if (!field.value.trim()) {
          field.style.borderColor = '#e74c3c';
          isValid = false;
        }
      });
      
      if (isValid) {
        this.style.display = 'none';
        mensajeExito.style.display = 'block';
        
        setTimeout(() => {
          this.reset();
          this.style.display = 'block';
          mensajeExito.style.display = 'none';
        }, 5000);
      }
    });
  }

  // Carrusel de Proyectos - VELOCIDAD AJUSTADA
  const carrusel = document.querySelector('.carrusel-container');
  if (carrusel) {
    const slides = document.querySelectorAll('.carrusel-slide');
    const slidesContainer = document.querySelector('.carrusel-slides');
    const prevBtn = document.querySelector('.carrusel-prev');
    const nextBtn = document.querySelector('.carrusel-next');
    const dots = document.querySelectorAll('.carrusel-indicador');
    
    let currentIndex = 0;
    let intervalId;
    const slideCount = slides.length;

    // Función para mover el carrusel con transición más lenta
    function goToSlide(index) {
      currentIndex = (index + slideCount) % slideCount;
      slidesContainer.style.transition = 'transform 1s ease-in-out'; // Transición más lenta (1s)
      slidesContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
      
      // Actualizar indicadores
      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === currentIndex);
      });
    }

    // Eventos para los botones
    if (prevBtn && nextBtn) {
      prevBtn.addEventListener('click', () => {
        resetInterval();
        goToSlide(currentIndex - 1);
      });

      nextBtn.addEventListener('click', () => {
        resetInterval();
        goToSlide(currentIndex + 1);
      });
    }

    // Eventos para los indicadores
    if (dots.length > 0) {
      dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
          resetInterval();
          goToSlide(index);
        });
      });
    }

    // Autoplay con intervalo más largo
    function startInterval() {
      intervalId = setInterval(() => {
        goToSlide(currentIndex + 1);
      }, 8000); // Cambiado a 8 segundos (antes era 5s)
    }

    function resetInterval() {
      clearInterval(intervalId);
      startInterval();
    }

    // Iniciar autoplay
    if (slides.length > 0) {
      startInterval();

      // Pausar autoplay al hacer hover
      carrusel.addEventListener('mouseenter', () => {
        clearInterval(intervalId);
      });

      carrusel.addEventListener('mouseleave', () => {
        startInterval();
      });

      // Manejo del teclado
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          resetInterval();
          goToSlide(currentIndex - 1);
        } else if (e.key === 'ArrowRight') {
          resetInterval();
          goToSlide(currentIndex + 1);
        }
      });
    }
  }
});