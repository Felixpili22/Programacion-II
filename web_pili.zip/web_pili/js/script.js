document.addEventListener('DOMContentLoaded', function() {
  // Menú Hamburguesa 
  const hamburger = document.querySelector('.hamburger');
  const menu = document.querySelector('.menu');
  
  if (hamburger && menu) {
    hamburger.addEventListener('click', function() {
      this.classList.toggle('active');
      menu.classList.toggle('active');
    });
  }

  // Formulario de Contacto
  const formulario = document.getElementById('formContacto');
  const mensajeExito = document.getElementById('mensajeExito');

  if (formulario && mensajeExito) {
    formulario.addEventListener('submit', function(e) {
      e.preventDefault();
      
      let isValid = true;
      const requiredFields = this.querySelectorAll('[required]');
      
      requiredFields.forEach(field => {
        field.style.borderColor = '#ddd';
        if (!field.value.trim()) {
          field.style.borderColor = '#e74c3c';
          isValid = false;
        }
      });
      
      if (isValid) {
        this.style.display = 'none';
        mensajeExito.style.display = 'block';
        
        setTimeout(() => {
          this.reset();
          this.style.display = 'block';
          mensajeExito.style.display = 'none';
        }, 5000);
      }
    });
  }

  // Carrusel de Proyectos
  const carruselSlides = document.querySelector('.carrusel-slides');
  if (carruselSlides) {
    const slides = document.querySelectorAll('.carrusel-slide');
    const indicadores = document.querySelectorAll('.carrusel-indicador');
    const prevBtn = document.querySelector('.carrusel-prev');
    const nextBtn = document.querySelector('.carrusel-next');
    let currentIndex = 0;
    const slideCount = slides.length;

    function goToSlide(index) {
      currentIndex = index;
      carruselSlides.style.transform = `translateX(-${currentIndex * 100}%)`;
      
      indicadores.forEach((ind, i) => {
        ind.classList.toggle('active', i === currentIndex);
      });
    }

    if (indicadores.length > 0) {
      indicadores.forEach((indicador, index) => {
        indicador.addEventListener('click', () => goToSlide(index));
      });
    }

    if (prevBtn && nextBtn) {
      prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex - 1 + slideCount) % slideCount;
        goToSlide(currentIndex);
      });
      
      nextBtn.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % slideCount;
        goToSlide(currentIndex);
      });
    }
  }
});